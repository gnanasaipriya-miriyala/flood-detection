"""SQLite storage for readings and the alert log."""
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

DB_PATH = Path(__file__).parent / "flood_data.db"
FMT = "%Y-%m-%d %H:%M:%S"
READING_COLS = ["time", "level_cm", "rainfall_mm_hr", "rate_cm_min", "status"]
ALERT_COLS = ["time", "status", "channel", "message", "result"]


@contextmanager
def _conn():
    conn = sqlite3.connect(DB_PATH)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    """Create tables if they don't exist."""
    with _conn() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS readings(
            time TEXT, level_cm REAL, rainfall_mm_hr REAL, rate_cm_min REAL, status TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS alerts(
            time TEXT, status TEXT, channel TEXT, message TEXT, result TEXT)""")


def save_reading(ts, level, rainfall, rate, status):
    """Store one reading (ts = epoch seconds)."""
    try:
        with _conn() as c:
            c.execute("INSERT INTO readings VALUES (?,?,?,?,?)",
                      (datetime.fromtimestamp(ts).strftime(FMT), level, rainfall, rate, status))
    except sqlite3.Error as exc:
        print(f"[DB] could not save reading: {exc}")


def save_alert(row):
    """Store one alert-log row (dict with time/status/channel/message/result)."""
    try:
        with _conn() as c:
            c.execute("INSERT INTO alerts VALUES (?,?,?,?,?)",
                      tuple(row[k] for k in ALERT_COLS))
    except sqlite3.Error as exc:
        print(f"[DB] could not save alert: {exc}")


def _range_query(table, cols, start, end):
    sql, params = f"SELECT * FROM {table} WHERE 1=1", []
    if start:
        sql += " AND time >= ?"; params.append(start.strftime(FMT))
    if end:
        sql += " AND time < ?"; params.append((end + timedelta(days=1)).strftime(FMT))
    sql += " ORDER BY time"
    try:
        with _conn() as c:
            return pd.read_sql_query(sql, c, params=params)
    except Exception as exc:   # keep the app alive on any DB problem
        print(f"[DB] query failed: {exc}")
        return pd.DataFrame(columns=cols)


def load_readings(start=None, end=None):
    """All readings between two dates (inclusive), as a DataFrame."""
    return _range_query("readings", READING_COLS, start, end)


def load_alerts(start=None, end=None):
    """Alert log between two dates (inclusive), newest first."""
    df = _range_query("alerts", ALERT_COLS, start, end)
    return df.iloc[::-1].reset_index(drop=True)
