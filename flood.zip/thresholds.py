"""Status classification logic: level + rate of rise + rainfall -> status."""

SAFE = "Safe"
WARNING = "Warning"
DANGER = "Danger"
SENSOR_ERROR = "Possible sensor error"
OFFLINE = "Sensor offline"

# Card colours used by the dashboard
STATUS_COLORS = {
    SAFE: "#2e7d32",          # green
    WARNING: "#f57c00",       # orange
    DANGER: "#c62828",        # red
    SENSOR_ERROR: "#6a1b9a",  # purple
    OFFLINE: "#616161",       # grey
}


def classify(level, rainfall, rate, warning=100.0, danger=150.0,
             fast_rate=15.0, abnormal_rate=60.0):
    """Return (status, reason).

    level         water level in cm
    rainfall      mm/hr
    rate          rate of rise in cm/min
    fast_rate     rise faster than this escalates the status one step
    abnormal_rate rise faster than this with NO rain is treated as a sensor glitch
    """
    # 1) False-alarm filter: huge jump but no rain -> probably a bad reading
    if rate >= abnormal_rate and rainfall < 0.5:
        return SENSOR_ERROR, (f"Level jumped {rate:.0f} cm/min with no rainfall - "
                              "check the sensor")

    # 2) Plain threshold check
    if level >= danger:
        status, reason = DANGER, f"Level {level:.0f} cm is above {danger:.0f} cm"
    elif level >= warning:
        status, reason = WARNING, f"Level {level:.0f} cm is above {warning:.0f} cm"
    else:
        status, reason = SAFE, "Level is within the safe range"

    # 3) Escalate one step if the water is rising fast
    if rate >= fast_rate:
        if status == SAFE:
            status, reason = WARNING, f"Rising fast ({rate:.1f} cm/min)"
        elif status == WARNING:
            status, reason = DANGER, f"Above warning AND rising fast ({rate:.1f} cm/min)"
    return status, reason
