"""Simulated ultrasonic water-level sensor, manual input, and rate-of-rise maths."""
import numpy as np


class SensorError(Exception):
    """Raised when no reading can be obtained from the sensor."""


class WaterSensor:
    """Fake ultrasonic sensor (cm) plus a rain gauge (mm/hr)."""
    BASELINE_CM = 60.0

    def __init__(self, seed=None):
        self.rng = np.random.default_rng(seed)
        self.level = self.BASELINE_CM
        self.rainfall = 0.0
        self.scenario_active = False
        self._spike_pending = False

    def start_flood_scenario(self):
        """Demo: level climbs steadily from Safe to Danger with growing rain."""
        self.level, self.rainfall, self.scenario_active = self.BASELINE_CM, 5.0, True

    def inject_spike(self):
        """Demo: one bogus +80 cm reading with zero rain (sensor glitch)."""
        self._spike_pending = True

    def reset(self):
        self.level, self.rainfall, self.scenario_active = self.BASELINE_CM, 0.0, False

    def read(self):
        """Advance the simulation one step and return {'level', 'rainfall'}."""
        if self.scenario_active:
            self.rainfall = min(90.0, self.rainfall + self.rng.uniform(0.5, 2.0))
            self.level += self.rng.uniform(0.8, 1.2)
            if self.level >= 180:          # scenario finished; drifts back to normal
                self.scenario_active = False
        else:
            # Occasional rain storm, otherwise rain decays away
            if self.rng.random() < 0.01:
                self.rainfall += self.rng.uniform(10, 40)
            self.rainfall = max(0.0, self.rainfall * 0.97 + self.rng.normal(0, 0.5))
            if self.rainfall < 0.3:
                self.rainfall = 0.0
            # Level drifts towards a rain-dependent target, with small noise
            target = self.BASELINE_CM + 1.2 * self.rainfall
            self.level += 0.05 * (target - self.level) + self.rng.normal(0, 0.3)
        self.level = max(0.0, self.level)

        level, rain = self.level, self.rainfall
        if self._spike_pending:
            level, rain, self._spike_pending = level + 80.0, 0.0, False
        return {"level": round(level, 1), "rainfall": round(rain, 1)}


def read_manual(level, rainfall):
    """Manual-input mode: values come straight from the sidebar sliders."""
    return {"level": float(level), "rainfall": float(rainfall)}


def rate_of_rise(history, window=5):
    """Rate of rise in cm/min from the last `window` readings (least-squares slope).

    history: list of dicts with 'ts' (epoch seconds) and 'level'.
    """
    pts = history[-window:]
    if len(pts) < 2:
        return 0.0
    t = np.array([p["ts"] for p in pts], dtype=float)
    y = np.array([p["level"] for p in pts], dtype=float)
    if t[-1] - t[0] <= 0:
        return 0.0
    slope_per_sec = np.polyfit(t - t[0], y, 1)[0]
    return float(slope_per_sec * 60.0)
