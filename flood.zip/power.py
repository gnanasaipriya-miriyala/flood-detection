"""Simulated battery / solar / mains power system (values accelerated for demo)."""


class PowerSystem:
    MAINS, BATTERY, SOLAR = "Mains", "Battery", "Solar"
    LOW_BATTERY_PCT = 20.0

    def __init__(self):
        self.battery = 85.0          # percent
        self.mains_available = True

    @property
    def source(self):
        """Mains if plugged in; else Solar during the day; else Battery."""
        if self.mains_available:
            return self.MAINS
        return self.SOLAR if self._is_day else self.BATTERY

    _is_day = True

    @property
    def low_battery(self):
        return self.battery < self.LOW_BATTERY_PCT

    def update(self, is_day):
        """Called once per reading: charge or drain the battery."""
        self._is_day = is_day
        if self.mains_available:
            self.battery = min(100.0, self.battery + 0.5)   # charging from mains
        elif is_day:
            self.battery = min(100.0, self.battery + 0.3)   # solar charging
        else:
            self.battery = max(0.0, self.battery - 0.6)     # night: draining
