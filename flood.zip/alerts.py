"""Simulated multi-channel alerts (local alarm, SMS, email) + anti-spam logic."""
import io
import json
import logging
import re
import wave
from datetime import datetime
from functools import lru_cache
from pathlib import Path

import numpy as np

from thresholds import DANGER, OFFLINE, WARNING

logging.basicConfig(level=logging.INFO, format="%(asctime)s [ALERT] %(message)s")
log = logging.getLogger("flood_alerts")

CONTACTS_FILE = Path(__file__).parent / "contacts.json"
ALERT_STATUSES = {WARNING, DANGER, OFFLINE}   # OFFLINE = maintenance alert
COOLDOWN_SECONDS = 300                        # 5 minutes


# ---------- contacts ----------
def load_contacts():
    """Read contacts.json -> {'phones': [...], 'emails': [...]}."""
    try:
        data = json.loads(CONTACTS_FILE.read_text())
        return {"phones": data.get("phones", []), "emails": data.get("emails", [])}
    except (OSError, json.JSONDecodeError):
        return {"phones": [], "emails": []}


def save_contacts(contacts):
    CONTACTS_FILE.write_text(json.dumps(contacts, indent=2))


def is_valid(kind, value):
    """Very simple validation. kind is 'phones' or 'emails'."""
    if kind == "phones":
        return re.fullmatch(r"\+?\d{7,15}", value) is not None
    return re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", value) is not None


# ---------- anti-spam ----------
def should_send(status, prev_status, last_sent, now):
    """Send only if the status changed or the 5-minute cooldown has passed."""
    return status != prev_status or (now - last_sent) >= COOLDOWN_SECONDS


# ---------- channels ----------
def _row(status, channel, message, result):
    return {"time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "status": status,
            "channel": channel, "message": message, "result": result}


def _send(channel, status, message, recipients, connected, failing_channel):
    """Simulate sending on SMS/Email. Returns one alert-log row."""
    if not recipients:
        result = "Skipped (no contacts)"
    elif not connected:
        result = "FAILED (no connectivity)"
    elif failing_channel == channel:
        result = "FAILED (simulated channel outage)"
    else:
        # ---- Real SMS would go here (Twilio) ----
        # from twilio.rest import Client
        # client = Client(ACCOUNT_SID, AUTH_TOKEN)
        # for number in recipients:
        #     client.messages.create(body=message, from_="+1555000000", to=number)
        #
        # ---- Real email / WhatsApp would go here ----
        # smtplib.SMTP_SSL(...).sendmail(...)   or Twilio WhatsApp:
        # client.messages.create(body=message, from_="whatsapp:+1415...", to="whatsapp:+91...")
        result = f"Delivered to {len(recipients)} recipient(s)"
    print(f"[{channel}] to {recipients}: {message} -> {result}")
    log.info("%s | %s | %s", channel, message, result)
    return _row(status, channel, message, result)


def dispatch_alerts(status, message, contacts, connected=True, failing_channel=None):
    """Fire all three channels. One channel failing never blocks the others."""
    return [
        _row(status, "Local alarm", message, "Delivered (siren + beep)"),
        _send("SMS", status, message, contacts["phones"], connected, failing_channel),
        _send("Email", status, message, contacts["emails"], connected, failing_channel),
    ]


# ---------- beep sound ----------
@lru_cache(maxsize=1)
def beep_wav():
    """Generate a 3-beep alarm as WAV bytes (no audio file needed)."""
    rate, parts = 22050, []
    t = np.linspace(0, 0.25, int(rate * 0.25), endpoint=False)
    tone = 0.5 * np.sin(2 * np.pi * 880 * t)
    gap = np.zeros(int(rate * 0.15))
    for _ in range(3):
        parts += [tone, gap]
    data = (np.concatenate(parts) * 32767).astype(np.int16)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)
        w.writeframes(data.tobytes())
    return buf.getvalue()
