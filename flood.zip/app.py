"""Flood Detection System - Streamlit main app (dashboard + navigation)."""
import random
import time
from datetime import datetime

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

import alerts
import database
import power
import sensors
import thresholds as th

st.set_page_config(page_title="Flood Detection System", page_icon="🌊", layout="wide")

NORMAL_REFRESH, LOW_POWER_REFRESH = 2.5, 8.0   # seconds
PAGES = ["Live Dashboard", "History", "Alert Contacts", "System Health & Settings"]
SIM, MANUAL = "Simulation mode", "Manual input mode"


# ------------------------------------------------------------------ state
def init_state():
    """Create everything we keep between refreshes (runs once per session)."""
    ss = st.session_state
    if "init" in ss:
        return
    database.init_db()
    ss.sensor = sensors.WaterSensor()
    ss.power = power.PowerSystem()
    ss.history = []                    # recent readings (list of dicts)
    ss.latest = None
    ss.status, ss.reason = th.SAFE, "Waiting for first reading..."
    ss.sensor_online = True
    ss.last_reading_time = None
    ss.last_tick = 0.0
    ss.offset = 0.0                    # calibration offset (cm)
    ss.alert_state = {"status": None, "last_sent": 0.0}
    ss.beep_pending = False
    ss.init = True


# ------------------------------------------------------------------ sidebar
def render_sidebar():
    """Draw sidebar controls and return them as a config dict."""
    ss, sb = st.session_state, st.sidebar
    sb.title("🌊 Flood Detection")
    page = sb.radio("Navigate", PAGES)

    sb.divider()
    mode = sb.radio("Input mode", [SIM, MANUAL])
    manual_level = manual_rain = 0
    if mode == MANUAL:
        manual_level = sb.slider("Water level (cm)", 0, 250, 60)
        manual_rain = sb.slider("Rainfall (mm/hr)", 0, 100, 0)

    sb.subheader("Thresholds")
    warning = sb.number_input("Warning at (cm)", value=100.0, step=5.0)
    danger = sb.number_input("Danger at (cm)", value=150.0, step=5.0)
    if danger <= warning:
        sb.error("Danger must be above Warning - using Warning + 1")
        danger = warning + 1
    fast = sb.number_input("Fast-rise limit (cm/min)", value=15.0, step=1.0)
    abnormal = sb.number_input("Abnormal jump (cm/min)", value=60.0, step=5.0)

    sb.subheader("Demo tools")
    if sb.button("▶ Run flood scenario"):
        ss.sensor.start_flood_scenario()
    if sb.button("⚡ Inject sensor spike"):
        ss.sensor.inject_spike()
    if sb.button("↺ Reset simulation"):
        ss.sensor.reset()
    sb.caption("Scenario / spike work in Simulation mode. In Manual mode, "
               "drag the level slider quickly to test escalation.")
    sensor_fail = sb.checkbox("Simulate sensor failure")
    conn_off = sb.checkbox("Simulate connectivity loss")
    chan_fail = sb.checkbox("Randomly fail one alert channel", value=True)

    sb.subheader("Power")
    if sb.button("🔌 Simulate power cut"):
        ss.power.mains_available = False
    if sb.button("Restore mains"):
        ss.power.mains_available = True
    if sb.button("🔋 Set battery to 25%"):
        ss.power.battery = 25.0
    tod = sb.selectbox("Time of day", ["Auto (clock)", "Day", "Night"])
    is_day = (6 <= datetime.now().hour < 18) if tod.startswith("Auto") else tod == "Day"

    interval = LOW_POWER_REFRESH if ss.power.low_battery else NORMAL_REFRESH
    return dict(page=page, mode=mode, manual_level=manual_level, manual_rain=manual_rain,
                warning=warning, danger=danger, fast=fast, abnormal=abnormal,
                sensor_fail=sensor_fail, connected=not conn_off, chan_fail=chan_fail,
                is_day=is_day, interval=interval)


# ------------------------------------------------------------------ sensing + alerts
def maybe_alert(status, message, now, cfg):
    """Send alerts on a status change (or after the 5-minute cooldown)."""
    ss = st.session_state
    state = ss.alert_state
    if status in alerts.ALERT_STATUSES and alerts.should_send(
            status, state["status"], state["last_sent"], now):
        failing = random.choice(["SMS", "Email", None]) if cfg["chan_fail"] else None
        for row in alerts.dispatch_alerts(status, message, alerts.load_contacts(),
                                          cfg["connected"], failing):
            database.save_alert(row)
        state["last_sent"] = now
        ss.beep_pending = True
    state["status"] = status


def take_reading(cfg):
    """Get one reading, classify it, store it and raise alerts. Never crashes."""
    ss = st.session_state
    now = time.time()
    if now - ss.last_tick < cfg["interval"] - 0.3:   # throttle: reruns from clicks
        return
    ss.last_tick = now
    ss.power.update(cfg["is_day"])

    try:
        if cfg["sensor_fail"]:
            raise sensors.SensorError("No reading received from sensor")
        if ss.power.battery <= 0:
            raise sensors.SensorError("Battery empty - sensor unpowered")
        if cfg["mode"] == SIM:
            raw = ss.sensor.read()
        else:
            raw = sensors.read_manual(cfg["manual_level"], cfg["manual_rain"])
    except sensors.SensorError as exc:
        ss.sensor_online, ss.status, ss.reason = False, th.OFFLINE, str(exc)
        maybe_alert(th.OFFLINE, f"MAINTENANCE: water-level sensor offline ({exc}).", now, cfg)
        return

    ss.sensor_online = True
    level = round(raw["level"] + ss.offset, 1)          # apply calibration
    reading = {"ts": now, "level": level, "rainfall": raw["rainfall"]}
    ss.history = (ss.history + [reading])[-300:]
    reading["rate"] = sensors.rate_of_rise(ss.history)
    status, reason = th.classify(level, reading["rainfall"], reading["rate"],
                                 cfg["warning"], cfg["danger"], cfg["fast"], cfg["abnormal"])
    reading["status"] = status
    ss.latest, ss.status, ss.reason, ss.last_reading_time = reading, status, reason, now
    database.save_reading(now, level, reading["rainfall"], reading["rate"], status)
    maybe_alert(status, f"FLOOD {status.upper()}: water {level:.0f} cm, "
                        f"rise {reading['rate']:.1f} cm/min, rain {reading['rainfall']:.0f} mm/hr. "
                        f"{reason}", now, cfg)


# ------------------------------------------------------------------ charts
def gauge(level, warning, danger):
    """Gauge coloured by the three threshold zones."""
    top = max(250.0, danger * 1.4)
    fig = go.Figure(go.Indicator(
        mode="gauge+number", value=level, number={"suffix": " cm"},
        gauge={"axis": {"range": [0, top]}, "bar": {"color": "#1565c0"},
               "steps": [{"range": [0, warning], "color": "#a5d6a7"},
                         {"range": [warning, danger], "color": "#ffcc80"},
                         {"range": [danger, top], "color": "#ef9a9a"}]}))
    fig.update_layout(height=260, margin=dict(t=30, b=10, l=20, r=20))
    return fig


def level_chart(df, warning, danger):
    fig = go.Figure(go.Scatter(x=df["dt"], y=df["level"], mode="lines", name="Level",
                               line=dict(color="#1565c0", width=3)))
    fig.add_hline(y=warning, line_dash="dash", line_color="orange", annotation_text="Warning")
    fig.add_hline(y=danger, line_dash="dash", line_color="red", annotation_text="Danger")
    fig.update_layout(title="Water level (cm)", height=350, margin=dict(t=40, b=10))
    return fig


def rain_chart(df):
    fig = go.Figure(go.Scatter(x=df["dt"], y=df["rainfall"], fill="tozeroy",
                               line=dict(color="#0288d1")))
    fig.update_layout(title="Rainfall (mm/hr)", height=250, margin=dict(t=40, b=10))
    return fig


# ------------------------------------------------------------------ pages
def page_dashboard(cfg):
    ss = st.session_state
    color = th.STATUS_COLORS[ss.status]
    flashing = ss.status in (th.DANGER, th.WARNING) and ss.sensor_online
    speed = "0.6s" if ss.status == th.DANGER else "1.4s"
    st.markdown(f"""
    <style>@keyframes flash {{ 50% {{ opacity: 0.35; }} }}</style>
    <div style="background:{color};color:white;padding:22px;border-radius:14px;text-align:center;
         {'animation: flash ' + speed + ' infinite;' if flashing else ''}">
      <div style="opacity:.85;letter-spacing:2px">CURRENT STATUS</div>
      <div style="font-size:52px;font-weight:800">{'🚨 ' if flashing else ''}{ss.status.upper()}</div>
      <div>{ss.reason}</div></div>""", unsafe_allow_html=True)
    if flashing:
        st.error("🔊 LOCAL ALARM ACTIVE - siren and alerts have been triggered.")
    if ss.status == th.OFFLINE:
        st.warning("🔧 Maintenance alert raised: check the sensor wiring/power.")

    latest = ss.latest
    c1, c2, c3 = st.columns(3)
    c1.metric("Water level", f"{latest['level']:.1f} cm" if latest else "—")
    c2.metric("Rainfall", f"{latest['rainfall']:.1f} mm/hr" if latest else "—")
    c3.metric("Rate of rise", f"{latest['rate']:+.1f} cm/min" if latest else "—")

    if latest:
        st.plotly_chart(gauge(latest["level"], cfg["warning"], cfg["danger"]),
                        width="stretch", key="gauge")
        df = pd.DataFrame(ss.history[-120:])
        df["dt"] = [datetime.fromtimestamp(t) for t in df["ts"]]
        st.plotly_chart(level_chart(df, cfg["warning"], cfg["danger"]),
                        width="stretch", key="level")
        st.plotly_chart(rain_chart(df), width="stretch", key="rain")

    st.subheader("Recent alerts")
    log = database.load_alerts().head(10)
    if log.empty:
        st.caption("No alerts yet.")
    else:
        st.dataframe(log, width="stretch", hide_index=True)


def load_sample_history():
    """Write 2 hours of synthetic history (Safe -> Danger) into the database."""
    rng, now, hist, prev = np.random.default_rng(), time.time(), [], None
    for i in range(120):
        ts = now - (120 - i) * 60
        level = 55 + 110 * (i / 119) ** 1.5 + rng.normal(0, 1)
        hist.append({"ts": ts, "level": level})
        rate = sensors.rate_of_rise(hist)
        rain = min(80.0, 2 + 0.6 * i)
        status, _ = th.classify(level, rain, rate)
        database.save_reading(ts, round(level, 1), round(rain, 1), round(rate, 2), status)
        if status != prev and status in (th.WARNING, th.DANGER):
            when = datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
            for ch in ("Local alarm", "SMS", "Email"):
                database.save_alert({"time": when, "status": status, "channel": ch,
                                     "message": f"Sample {status} alert",
                                     "result": "Delivered (sample)"})
        prev = status


def page_history():
    st.header("Historical data")
    if st.button("Generate sample flood history"):
        load_sample_history()
        st.success("Sample data added.")
    full = database.load_readings()
    if full.empty:
        st.info("No saved readings yet. Let the dashboard run or generate sample data.")
        return
    times = pd.to_datetime(full["time"])
    picked = st.date_input("Date range", value=(times.min().date(), times.max().date()))
    if not isinstance(picked, (tuple, list)) or len(picked) < 2:
        st.info("Pick an end date.")
        return
    start = datetime.combine(picked[0], datetime.min.time())
    end = datetime.combine(picked[1], datetime.min.time())
    df, log = database.load_readings(start, end), database.load_alerts(start, end)
    if df.empty:
        st.info("No readings in that range.")
        return
    c1, c2, c3 = st.columns(3)
    c1.metric("Max level", f"{df['level_cm'].max():.1f} cm")
    c2.metric("Average level", f"{df['level_cm'].mean():.1f} cm")
    c3.metric("Alerts sent", len(log))
    st.line_chart(df.set_index("time")["level_cm"])
    st.dataframe(df, width="stretch", hide_index=True)
    st.download_button("⬇ Download CSV", df.to_csv(index=False), "flood_readings.csv", "text/csv")
    st.subheader("Alert log")
    st.dataframe(log, width="stretch", hide_index=True)


def page_contacts():
    st.header("Alert contacts")
    contacts = alerts.load_contacts()
    col_p, col_e = st.columns(2)
    for col, kind, label in ((col_p, "phones", "phone number"), (col_e, "emails", "email")):
        with col:
            st.subheader(kind.capitalize())
            for item in contacts[kind]:
                st.write("•", item)
            with st.form(f"add_{kind}", clear_on_submit=True):
                value = st.text_input(f"Add {label}").strip()
                if st.form_submit_button("Add"):
                    if not alerts.is_valid(kind, value):
                        st.error(f"Invalid {label}.")
                    elif value in contacts[kind]:
                        st.warning("Already in the list.")
                    else:
                        contacts[kind].append(value)
                        alerts.save_contacts(contacts)
                        st.rerun()
            if contacts[kind]:
                gone = st.selectbox(f"Remove {label}", contacts[kind], key=f"rm_{kind}")
                if st.button("Remove", key=f"btn_{kind}"):
                    contacts[kind].remove(gone)
                    alerts.save_contacts(contacts)
                    st.rerun()
    st.caption("Auto-refresh is paused on this page so forms aren't interrupted.")


def page_health():
    ss = st.session_state
    st.header("System health & settings")
    p = ss.power
    if p.low_battery:
        st.warning("🪫 Low battery (<20%) - low-power mode: refresh slowed to "
                   f"{LOW_POWER_REFRESH:.0f}s.")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Battery", f"{p.battery:.0f}%")
    c2.metric("Power source", p.source)
    c3.metric("Sensor", "Online" if ss.sensor_online else "Offline")
    c4.metric("Connectivity", "Online" if st.session_state.get("connected", True) else "Offline")
    st.progress(int(p.battery) / 100, text="Battery level")
    last = (datetime.fromtimestamp(ss.last_reading_time).strftime("%H:%M:%S")
            if ss.last_reading_time else "never")
    st.write(f"**Last reading:** {last}")

    st.subheader("Calibration")
    ss.offset = st.number_input("Sensor offset (cm) - added to every reading",
                                value=float(ss.offset), step=0.5)
    st.caption("Example: sensor reads 3 cm too high -> enter -3.")


# ------------------------------------------------------------------ main
def main():
    init_state()
    cfg = render_sidebar()
    st.session_state.connected = cfg["connected"]
    take_reading(cfg)

    {"Live Dashboard": lambda: page_dashboard(cfg), "History": page_history,
     "Alert Contacts": page_contacts, "System Health & Settings": page_health}[cfg["page"]]()

    if st.session_state.beep_pending:                 # local alarm sound
        st.audio(alerts.beep_wav(), format="audio/wav", autoplay=True)
        st.session_state.beep_pending = False

    if cfg["page"] != "Alert Contacts":               # auto-refresh
        time.sleep(cfg["interval"])
        st.rerun()


main()
