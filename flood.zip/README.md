# 🌊 Flood Detection System (Streamlit, simulated)

Beginner-friendly flood monitor that runs on a laptop with **no hardware**. All sensors,
power and alert channels are simulated.

## Install & run
```bash
cd flood_detection
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```
Needs Python 3.10+.

## Try it
1. **Sidebar → ▶ Run flood scenario**: level climbs Safe → Warning → Danger, alerts fire.
2. **Inject sensor spike**: +80 cm with zero rain -> "Possible sensor error" (not Danger).
3. **Manual input mode**: sliders for level and rainfall. Drag level fast to test escalation.
4. **Simulate power cut** + *Time of day = Night* to watch the battery drain; "Set battery to 25%"
   then let it fall below 20% for low-power mode.
5. **Simulate sensor failure** -> "Sensor offline" + maintenance alert.
6. **Simulate connectivity loss** or leave "Randomly fail one alert channel" ticked to see
   SMS/Email fail while the local alarm still delivers.
7. **History → Generate sample flood history** to test date filter, stats and CSV download.

## Files
| File | Purpose |
|---|---|
| app.py | Streamlit UI, navigation, reading loop, charts |
| sensors.py | Simulated sensor, manual input, rate-of-rise |
| thresholds.py | Status classification (thresholds, escalation, sensor-error filter) |
| alerts.py | Local/SMS/Email simulation, contacts, 5-min de-dupe, beep generator |
| database.py | SQLite storage (`flood_data.db`, created automatically) |
| power.py | Battery / solar / mains simulation |
| contacts.json | Registered phone numbers and emails |

## Feature notes
- **Status logic**: level vs thresholds; fast rise (default 15 cm/min) escalates one step;
  a huge jump (default 60 cm/min) with no rain = "Possible sensor error".
- **Alerts** trigger when status changes to Warning/Danger (or Sensor offline), and are not
  repeated unless the status changes or 5 minutes pass.
- **Auto-refresh** is 2.5 s (8 s in low-power mode). It's paused on the Alert Contacts page.
- Battery values are accelerated for demo purposes.
- Browsers may block autoplay sound until you click the page once.

## How to replace the simulation with real hardware
- **Sensor**: wire an HC-SR04 ultrasonic sensor to a Raspberry Pi (GPIO trigger/echo, use a
  voltage divider on echo) or ESP32. Level = sensor mounting height − measured distance.
  Replace `WaterSensor.read()` in `sensors.py` with a function returning the same dict.
  Raise `SensorError` on timeout.
- **Rain gauge**: tipping-bucket gauge on a GPIO interrupt pin.
- **Data transport**: have the ESP32/Pi publish JSON via **MQTT** (e.g. `paho-mqtt`,
  topic `flood/site1/reading`); subscribe in the app and return the latest message.
- **SMS**: uncomment the Twilio block in `alerts._send()` and set your account SID/token
  via environment variables. Use a Twilio WhatsApp sender or SMTP for email.
- **Power**: read battery voltage through an ADC (e.g. ADS1115) and mains/solar status from
  a GPIO; return them from `PowerSystem`.
- **Local alarm**: drive a relay/buzzer from a GPIO pin when status is Warning/Danger.
